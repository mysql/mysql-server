#!/bin/sh
unset NDB_CONNECTSTRING
unset NDB_HOME
export NDB_DEMO=$MYSQLCLUSTER_TOP/ndb/demos
cd $NDB_DEMO

# Edit file system path

mv 2-node/2-mgm-1/config.ini config.tmp
sed -e s,"WRITE_PATH_TO_FILESYSTEM_2_HERE",$NDB_DEMO/2-node/2-db-2/filesystem,g \
    < config.tmp > 2-node/2-mgm-1/config.ini
rm config.tmp
mv 2-node/2-mgm-1/config.ini config.tmp
sed -e s,"WRITE_PATH_TO_FILESYSTEM_3_HERE",$NDB_DEMO/2-node/2-db-3/filesystem,g \
    < config.tmp > 2-node/2-mgm-1/config.ini
rm config.tmp

# Start management server

pushd 2-node/2-mgm-1
xterm -T "Demo 2 NDB Management Server" -geometry 80x10 -e mgmtsrvr -c config.ini &
popd

# Start database node 

pushd 2-node/2-db-2
xterm -T "Demo 2 NDB Cluster DB Node 2" -geometry 80x10 -e ndb -i &
popd

# Start database node 

pushd 2-node/2-db-3
xterm -T "Demo 2 NDB Cluster DB Node 3"  -geometry 80x10 -e ndb -i &
popd

# Start database node 

pushd 2-node/2-api-4
xterm -T "Demo 2 NDB Cluster API Node 4" -geometry 80x10 &
popd
