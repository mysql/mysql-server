#!/bin/sh
unset NDB_CONNECTSTRING
unset NDB_HOME
export NDB_DEMO=$MYSQLCLUSTER_TOP/ndb/demos
cd $NDB_DEMO

# Edit file system path

mv 1-node/1-mgm-1/config.ini config.tmp
sed -e s,"WRITE_PATH_TO_FILESYSTEM_2_HERE",$NDB_DEMO/1-node/1-db-2/filesystem,g \
    < config.tmp > 1-node/1-mgm-1/config.ini
rm config.tmp

# Start management server

pushd 1-node/1-mgm-1
xterm -T "Demo 1 NDB Cluster MGM Node 1" -geometry 80x10 -e mgmtsrvr -c config.ini &
popd

# Start database node 

pushd 1-node/1-db-2
xterm -T "Demo 1 NDB Cluster DB Node 2" -geometry 80x10 -e ndb -i &
popd

# Start xterm for application programs

pushd 1-node/1-api-3
xterm -T "Demo 1 NDB Cluster API Node 3" -geometry 80x10 &
popd
