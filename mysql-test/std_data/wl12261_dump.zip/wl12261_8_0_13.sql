-- MySQL dump 10.13  Distrib 8.0.13, for Linux (x86_64)
--
-- Host: localhost    Database: db1
-- ------------------------------------------------------
-- Server version	8.0.13-debug

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;

USE `db1`;

--
-- Table structure for table `c1`
--

DROP TABLE IF EXISTS `c1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `c1` (
  `f1` int(11) NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c1`
--

LOCK TABLES `c1` WRITE;
/*!40000 ALTER TABLE `c1` DISABLE KEYS */;
/*!40000 ALTER TABLE `c1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c2`
--

DROP TABLE IF EXISTS `c2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `c2` (
  `f1` int(11) NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- Orignal: ") ENGINE=CSV DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='y';"
-- WL#12261 encryption request for SE that does not support encryption is not allowed.
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c2`
--

LOCK TABLES `c2` WRITE;
/*!40000 ALTER TABLE `c2` DISABLE KEYS */;
/*!40000 ALTER TABLE `c2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c3`
--

DROP TABLE IF EXISTS `c3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `c3` (
  `f1` int(11) NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c3`
--

LOCK TABLES `c3` WRITE;
/*!40000 ALTER TABLE `c3` DISABLE KEYS */;
/*!40000 ALTER TABLE `c3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `h1`
--

DROP TABLE IF EXISTS `h1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `h1` (
  `f1` int(11) DEFAULT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `h1`
--

LOCK TABLES `h1` WRITE;
/*!40000 ALTER TABLE `h1` DISABLE KEYS */;
/*!40000 ALTER TABLE `h1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `h2`
--

DROP TABLE IF EXISTS `h2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `h2` (
  `f1` int(11) DEFAULT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- Orignal: ") ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='y';"
-- WL#12261 encryption request for SE that does not support encryption is not allowed.
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `h2`
--

LOCK TABLES `h2` WRITE;
/*!40000 ALTER TABLE `h2` DISABLE KEYS */;
/*!40000 ALTER TABLE `h2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `h3`
--

DROP TABLE IF EXISTS `h3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `h3` (
  `f1` int(11) DEFAULT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `h3`
--

LOCK TABLES `h3` WRITE;
/*!40000 ALTER TABLE `h3` DISABLE KEYS */;
/*!40000 ALTER TABLE `h3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i1`
--

DROP TABLE IF EXISTS `i1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i1` (
  `f1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i1`
--

LOCK TABLES `i1` WRITE;
/*!40000 ALTER TABLE `i1` DISABLE KEYS */;
/*!40000 ALTER TABLE `i1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i2`
--

DROP TABLE IF EXISTS `i2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i2` (
  `f1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='y';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i2`
--

LOCK TABLES `i2` WRITE;
/*!40000 ALTER TABLE `i2` DISABLE KEYS */;
/*!40000 ALTER TABLE `i2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i3`
--

DROP TABLE IF EXISTS `i3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i3` (
  `f1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i3`
--

LOCK TABLES `i3` WRITE;
/*!40000 ALTER TABLE `i3` DISABLE KEYS */;
/*!40000 ALTER TABLE `i3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_part1`
--

DROP TABLE IF EXISTS `i_part1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_part1` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) /*!50100 TABLESPACE `innodb_file_per_table` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
/*!50100 PARTITION BY RANGE (`id`)
(PARTITION p0 VALUES LESS THAN (10) ENGINE = InnoDB,
 PARTITION p1 VALUES LESS THAN (20) ENGINE = InnoDB,
 PARTITION p2 VALUES LESS THAN (30) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_part1`
--

LOCK TABLES `i_part1` WRITE;
/*!40000 ALTER TABLE `i_part1` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_part1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_part2`
--

DROP TABLE IF EXISTS `i_part2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_part2` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) /*!50100 TABLESPACE `innodb_file_per_table` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='y'
/*!50100 PARTITION BY RANGE (`id`)
(PARTITION p0 VALUES LESS THAN (10) ENGINE = InnoDB,
 PARTITION p1 VALUES LESS THAN (20) ENGINE = InnoDB,
 PARTITION p2 VALUES LESS THAN (30) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_part2`
--

LOCK TABLES `i_part2` WRITE;
/*!40000 ALTER TABLE `i_part2` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_part2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_part3`
--

DROP TABLE IF EXISTS `i_part3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_part3` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) /*!50100 TABLESPACE `innodb_file_per_table` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='n'
/*!50100 PARTITION BY RANGE (`id`)
(PARTITION p0 VALUES LESS THAN (10) ENGINE = InnoDB,
 PARTITION p1 VALUES LESS THAN (20) ENGINE = InnoDB,
 PARTITION p2 VALUES LESS THAN (30) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_part3`
--

LOCK TABLES `i_part3` WRITE;
/*!40000 ALTER TABLE `i_part3` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_part3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_ts1`
--

DROP TABLE IF EXISTS `i_ts1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_ts1` (
  `f1` int(11) DEFAULT NULL
) /*!50100 TABLESPACE `ts1` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_ts1`
--

LOCK TABLES `i_ts1` WRITE;
/*!40000 ALTER TABLE `i_ts1` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_ts1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_ts2`
--

DROP TABLE IF EXISTS `i_ts2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_ts2` (
  `f1` int(11) DEFAULT NULL
) /*!50100 TABLESPACE `ts2` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_ts2`
--

LOCK TABLES `i_ts2` WRITE;
/*!40000 ALTER TABLE `i_ts2` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_ts2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_ts3`
--

DROP TABLE IF EXISTS `i_ts3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_ts3` (
  `f1` int(11) DEFAULT NULL
) /*!50100 TABLESPACE `ts3` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ENCRYPTION='y';
-- Original : ") /*!50100 TABLESPACE `ts3` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;"
-- WL#12261 expects user to explicity state the tablespace encryption type,
-- if it does not match the tables schema default encryption.
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_ts3`
--

LOCK TABLES `i_ts3` WRITE;
/*!40000 ALTER TABLE `i_ts3` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_ts3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i_ts4`
--

DROP TABLE IF EXISTS `i_ts4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `i_ts4` (
  `f1` int(11) DEFAULT NULL
) /*!50100 TABLESPACE `ts4` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i_ts4`
--

LOCK TABLES `i_ts4` WRITE;
/*!40000 ALTER TABLE `i_ts4` DISABLE KEYS */;
/*!40000 ALTER TABLE `i_ts4` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-16 19:47:55
